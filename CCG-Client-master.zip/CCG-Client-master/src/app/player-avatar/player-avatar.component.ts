import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ccg-player-avatar',
  templateUrl: './player-avatar.component.html',
  styleUrls: ['./player-avatar.component.css']
})
export class PlayerAvatarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
