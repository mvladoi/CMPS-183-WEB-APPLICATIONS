import { SortableDirective } from './sortable.directive';

describe('SortableDirective', () => {
  it('should create an instance', () => {
    const directive = new SortableDirective();
    expect(directive).toBeTruthy();
  });
});
