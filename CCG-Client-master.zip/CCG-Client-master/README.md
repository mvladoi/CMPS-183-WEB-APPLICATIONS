# Card Game Client

A client for a websockets based card game, written using Angular and Typescript.

You can find the coresponding server at <https://github.com/WilliamRitson/CCG-Server>. The game's core logic is shared between the client and the server. To facilitate this sharing it uses a [git submodule](https://git-scm.com/book/en/v2/Git-Tools-Submodules) which is hosted at <https://github.com/WilliamRitson/CCG-Model>.

## Installation
Run `git clone --recursive https://github.com/WilliamRitson/CCG-Client.git
` to clone the project and its submodule (do this wherever you want the project stored on your computer).

Install [node](https://nodejs.org/en/) using an installer. This should also install npm.

Run `npm install -g yarn` to get [yarn](https://www.npmjs.com/package/yarn).

Run `npm install -g @angular/cli` to get [angular cli](https://github.com/angular/angular-cli).

Finally run `yarn` within the project directory (the place you cloned it) to install the project's dependencies.


## Images
The project uses svg (vector) images which are then rendered into png (bitmap) images before being released. However, only the svg sources should be stored in the repository. There is a script in the images folder which should render all the svgs. It requires [inkscape](https://inkscape.org/en/release/0.92.2/) be available in your path. Inkscape is also useful for creating new images.


## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive/pipe/service/class/module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

# Ideas and Todo
See (https://trello.com/b/0YypsJaV/ccg).

